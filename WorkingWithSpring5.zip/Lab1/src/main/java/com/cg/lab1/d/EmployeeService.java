package com.cg.lab1.d;

public interface EmployeeService {
public Employee getDetails(int empId);
}
