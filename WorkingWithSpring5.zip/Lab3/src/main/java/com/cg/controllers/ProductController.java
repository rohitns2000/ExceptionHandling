package com.cg.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Product;
import com.cg.service.ProductServ;
import com.cg.service.ProductServImpl;

import sun.print.resources.serviceui;

@Controller
public class ProductController {
	
	
 ProductServ service = new ProductServImpl();

	@GetMapping("/")
	public String showAdd(Model model) {
		Product p=new Product();
		model.addAttribute("product",p);
		service.populate();
//		List<Product> lst = service.getAllProducts();
//		model.addAttribute("lst",lst);
		return "add";
	}
	
	@GetMapping("/products")
	public String showProducts(Model model) {
		Product p=new Product();
		model.addAttribute("product",p);
		List<Product> lst = service.getAllProducts();
		for(Product pr1 : lst)
		{
			pr1.toString();
		}
		
		model.addAttribute("lst",lst);
		return "products";
	}
	
	@PostMapping("/add")
	public String showAdd(@Valid @ModelAttribute("product") Product pr,BindingResult results, Model model) 
	{
		String msg1="";
		System.out.println("Processing "+pr.getProdName());
		if(!results.hasErrors()) {
			msg1="No Errors found!";
			service.addProduct(pr);
			model.addAttribute("message",msg1);
			List<Product> lst = service.getAllProducts();
			model.addAttribute("lst",lst);
			for(Product tr1 : lst)
			{
				System.out.println(tr1.getProdId()+" "+tr1.getProdName()+" "+tr1.getProdPrice());
			}
			service.addProduct(pr);
			//List<Product> lst1 = service.getAllProducts();
			return "products";
		}
		else {
			msg1=results.getErrorCount()+ " errors occurred!";
			model.addAttribute("msg",msg1);
			return "add";
		}
	}
	
}