package com.cg.dao;

import java.util.List;

import com.cg.entities.Product;

public interface ProductDAO {
	public List<Product> getAllProducts();
	public boolean addProduct(Product tr);
	public void deleteProduct(Product tr);
	public void populate() ;
}
