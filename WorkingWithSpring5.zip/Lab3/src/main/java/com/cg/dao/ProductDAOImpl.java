package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import com.cg.entities.Product;

public class ProductDAOImpl implements ProductDAO{
	
	List <Product> lst = new ArrayList<Product>();

	public List<Product> getAllProducts() {
		return lst;
	}
	
	public void populate() {
		lst.add(new Product(1001,"Shampoooo",25000.00));
		lst.add(new Product(1002,"Comb",2000.00));
		lst.add(new Product(1003,"Hair Drier",5000.00));
	}

	public boolean addProduct(Product tr) {
		lst.add(tr);
		return true;
	}

	public void deleteProduct(Product tr) {
		lst.remove(tr);
	}
	

}
