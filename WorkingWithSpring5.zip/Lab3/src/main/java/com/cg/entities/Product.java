package com.cg.entities;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;

import com.sun.istack.internal.NotNull;

public class Product {
	
	@NotNull
	@Max(value=10000,message="Trainee ID Cannot be greater than 10000")
	private int prodId;
	
	@NotEmpty(message="Name cannot be empty!")
	private String prodName;
	
	@NotNull
	private double prodPrice;
	
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public Product(int prodId, String prodName, double prodPrice) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
	}
	public Product() {
		super();
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", prodPrice=" + prodPrice + "]";
	}
	
	
}
