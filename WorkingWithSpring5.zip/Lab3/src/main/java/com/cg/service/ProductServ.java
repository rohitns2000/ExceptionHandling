package com.cg.service;

import java.util.List;

import com.cg.entities.Product;

public interface ProductServ {
	public List<Product> getAllProducts();
//	public Product getProduct(int id);
	public boolean addProduct(Product tr);
	public void populate() ;
}
