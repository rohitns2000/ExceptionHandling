package com.cg.service;

import java.util.List;

import com.cg.dao.ProductDAO;
import com.cg.dao.ProductDAOImpl;
import com.cg.entities.Product;

public class ProductServImpl implements ProductServ{
	ProductDAO dao = new ProductDAOImpl();
	
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

//	public Product getProduct(int id) {
//		List<Product> lst = dao.getAllProducts();
//		for(Product tr : lst)
//		{
//			if(id == tr.getTraineeId())
//			{
//				return tr;
//			}
//		}
//		return null;
//	}

	public boolean addProduct(Product tr) {
		// TODO Auto-generated method stub
		return dao.addProduct(tr);
	}

	public void populate() {
		dao.populate();
		
	}


}
