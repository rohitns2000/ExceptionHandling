package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.traineeDAO;
import com.cg.dao.traineeDAOImpl;
import com.cg.entities.Trainee;
import com.cg.exceptions.ApplicationException;

@Service
@Transactional
public class TraineeServImpl implements TraineeServ{
	@Autowired private traineeDAO dao;
	
	@Transactional(readOnly=true)
	public List<Trainee> getAllTrainee() {
		List<Trainee> lst = dao.getAllTrainee();
		if(lst == null || lst.isEmpty()) {
            throw new ApplicationException("List of Trainees are Empty!");
        }
		return lst;
	}
	
	@Transactional(readOnly=true)
	public Trainee getTrainee(int id) {
		Trainee t1 = dao.find(id);
		if(t1 == null) {
            throw new ApplicationException("Employee does not exists!");
        }
		return t1;
	}

	@Transactional(readOnly=true)
	public boolean addTrainee(Trainee tr) {
		Trainee b1 = dao.find(tr.getTraineeId());
		if(b1!=null)
		{
			throw new ApplicationException("Employee Already exists!");
		}
		else
		{
			return dao.addTrainee(tr);
		}
		
	}

	public void deleteTrainee(Integer tr) {
		dao.deleteTrainee(tr);
	}

	public void modify(Trainee t) {
		dao.modify(t);
		
	}

}
