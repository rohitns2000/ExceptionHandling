package com.cg.bootdemo2.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bootdemo2.entities.Movie;
import com.cg.bootdemo2.services.MovieService;

@RestController
public class MovieController {
@Autowired MovieService movie;
@GetMapping("/")
public void main() {
	movie.save(new Movie(101,"Harry Potter-1","Rohit",15000.00,"Thriller"));
	movie.save(new Movie(102,"Harry Potter-2","Subhanshu",25000.00,"Romance"));
	movie.save(new Movie(103,"Harry Potter-3","Sakshi",35000.00,"Jonre"));
}
@GetMapping("/find/{id}")
	public Movie find(@PathVariable Integer id) {
		return movie.findById(id);
	}
@GetMapping("/findall")
	public List<Movie> find(){
	List<Movie> mov = movie.findall();
		return mov;
	
}

@PutMapping(value="/new",consumes= {"application/json"})
public String save(@RequestBody Movie movie1) {
    movie.save(movie1);
    return "Movie added!";
}

@PutMapping(value="/update",consumes= {"application/json"})
public String update(@RequestBody Movie movie1) {
	movie.updateMovie(movie1);
    return "Movie updated";
}      

@GetMapping("/delete/{id}")
public void delete(@PathVariable Integer id) {
	movie.deleteMovie(id);
}

}
