package com.cg.bootdemo2.services;

import java.util.List;

import com.cg.bootdemo2.entities.Movie;

public interface MovieService {
void save(Movie m);
Movie findById(Integer id);
List<Movie> findall();
void updateMovie(Movie m);
void deleteMovie(int m);
}
