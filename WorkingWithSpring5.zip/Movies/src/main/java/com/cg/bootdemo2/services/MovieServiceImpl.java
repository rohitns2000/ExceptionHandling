package com.cg.bootdemo2.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootdemo2.dao.MovieDAO;
import com.cg.bootdemo2.entities.Movie;
@Service
@Transactional
public class MovieServiceImpl implements MovieService{
	@Autowired MovieDAO dao;
	@Override
	@Transactional
	public void save(Movie m) {
		dao.save(m);
		
	}

	@Override
	public Movie findById(Integer id) {
		return dao.findById(id).get();
	}

	@Override
	public List<Movie> findall() {
		
		return dao.findAll();
	}

	@Override
	public void updateMovie(Movie m) {
		List <Movie> lst = dao.findAll();

		Movie m1 = new Movie();
		Optional<Movie> temp = dao.findById(m.getId());
        if(temp.isPresent()) {
        	m1.setId(m.getId());
        	m1.setBudget(m.getBudget());
        	m1.setDirector(m.getDirector());
        	m1.setGenre(m.getGenre());
        	m1.setTitle(m.getTitle());
        	dao.save(m1);
        }
        else
        {
        	dao.save(m);
        }
		
	}

	@Override
	public void deleteMovie(int m) {
		dao.deleteById(m);
		
	}
	
	

}
