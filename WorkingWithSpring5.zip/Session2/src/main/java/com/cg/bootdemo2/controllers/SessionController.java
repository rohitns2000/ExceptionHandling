package com.cg.bootdemo2.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bootdemo2.entities.Session_Manager;
import com.cg.bootdemo2.services.SessionService;

@RestController
public class SessionController {
@Autowired SessionService service;

//I will be using jpa repository for all the action
//the following urls are entered in browser to get the required attribute
//have used Default Layered architecture
//As mode is an identifier I have Changed the mode to mode1 ...(Realized it later after readeing docs)
// The functions which i have implemented are - adding default values, finding a particular record, modifyoing a particular record, 
//deleting a record and adding a new record from the user by consuming the json data
//proper exception handelling are placed accordingly...
@GetMapping("/")
public void main() {
	service.save(new Session_Manager(101,"rohit",12,"Mrs.Roma","class"));
	service.save(new Session_Manager(102,"bilal",11,"Mrs.Koma","Online"));
	service.save(new Session_Manager(103,"gazi",23,"Mrs.Tina","offline"));
}
@GetMapping("/find/{id}")
	public Session_Manager find(@PathVariable Integer id) {
		return service.findById(id);
	}
@GetMapping("/findall")
	public List<Session_Manager> find(){
	List<Session_Manager> mov = service.findall();
		return mov;
	
}

@PutMapping(value="/new",consumes= {"application/json"})
public String save(@RequestBody Session_Manager movie1) {
    service.save(movie1);
    return "Session added!";
}

@PutMapping(value="/update",consumes= {"application/json"})
public String update(@RequestBody Session_Manager movie1) {
	service.update(movie1);
    return "Session updated";
}      

@GetMapping("/delete/{id}")
public void delete(@PathVariable Integer id) {
	service.deleteSession(id);
}

}
