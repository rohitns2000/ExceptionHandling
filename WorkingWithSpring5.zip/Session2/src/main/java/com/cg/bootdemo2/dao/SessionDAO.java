package com.cg.bootdemo2.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bootdemo2.entities.Session_Manager;

@Repository
public interface SessionDAO extends JpaRepository<Session_Manager,Integer>{
	
}
