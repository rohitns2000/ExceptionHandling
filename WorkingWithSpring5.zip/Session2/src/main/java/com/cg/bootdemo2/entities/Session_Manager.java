package com.cg.bootdemo2.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "sess")
public class Session_Manager {
@Id
private Integer id;

@Column(name="Name",length=20)
@NotEmpty(message="Name cannot be empty!")
private String name;

@Column(name="Duration",length=20)
@NotNull
private Integer duration;

@Column(name="Faculty",length=20)
@NotEmpty(message="faculty cannot be empty!")
private String faculty;

@Column(name="Mode1",length=20)
@NotEmpty(message="Mode cannot be empty!")
private String mode;


public Session_Manager() {
	super();
}
public Session_Manager(Integer id, String name, Integer duration, String faculty, String mode) {
	super();
	this.id = id;
	this.name = name;
	this.duration = duration;
	this.faculty = faculty;
	this.mode = mode;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getDuration() {
	return duration;
}
public void setDuration(Integer duration) {
	this.duration = duration;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}
public String getMode() {
	return mode;
}
public void setMode(String mode) {
	this.mode = mode;
}
@Override
public String toString() {
	return "Session [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", mode=" + mode
			+ "]";
}
}
