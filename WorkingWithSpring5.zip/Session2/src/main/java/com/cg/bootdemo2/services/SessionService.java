package com.cg.bootdemo2.services;

import java.util.List;

import com.cg.bootdemo2.entities.Session_Manager;

public interface SessionService {
void save(Session_Manager m);
Session_Manager findById(Integer id);
List<Session_Manager> findall();
void update(Session_Manager m);
public void deleteSession(int m);
}
