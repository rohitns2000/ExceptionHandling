package com.cg.bootdemo2.services;

import java.util.List;import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootdemo2.dao.SessionDAO;
import com.cg.bootdemo2.entities.Session_Manager;
import com.cg.bootdemo2.exceptions.ApplicationException;

@Service
@Transactional
public class SessionServiceImpl implements SessionService{
	@Autowired SessionDAO dao;
	@Override
	@Transactional
	public void save(Session_Manager m) {
		if(m == null) {
            throw new ApplicationException("Session does not exists!");
        }
		else {
			dao.save(m);
		}
		
		
	}

	@Override
	@Transactional
	public Session_Manager findById(Integer id) {
		if(dao.findById(id).get() == null) {
            throw new ApplicationException("Session does not exists!");
        }else {
        	return dao.findById(id).get();
        }
		
	}

	@Override
	@Transactional
	public List<Session_Manager> findall() {
		
		return dao.findAll();
	}

	@Override
	@Transactional
	public void update(Session_Manager m) {
		if(m == null) {
            throw new ApplicationException("Session does not exists!");
        }
		else {
			List <Session_Manager> lst = dao.findAll();
			Session_Manager m1 = new Session_Manager();
			Optional<Session_Manager> temp = dao.findById(m.getId());
	        if(temp.isPresent()) {
	        	m1.setDuration(m.getDuration());
	        	m1.setName(m.getName());
	        	m1.setFaculty(m.getFaculty());
	        	m1.setId(m.getId());
	        	m1.setMode(m.getMode());
	        	dao.save(m1);
	        }
	        else
	        {
	        	dao.save(m);
	        }
		}
	}
	
	@Override
	@Transactional
	public void deleteSession(int m) {
		dao.deleteById(m);
		
	}
	
	

}
